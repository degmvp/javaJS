A simple Timer created with html, css and pure JavaScript. 
