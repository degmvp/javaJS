const percentage = (nominator, denominator) => {
  var result = nominator / denominator;
  console.log(nominator + " equivale a " + result * 100 + "% de " + denominator);
};

percentage(40, 50);
